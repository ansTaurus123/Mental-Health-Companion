
import { randomBytes, createCipheriv, createDecipheriv } from 'crypto';

const ALGORITHM = 'aes-256-cbc';
const KEY = randomBytes(32); // For development, in production this should come from env

export function encrypt(text: string) {
  const iv = randomBytes(16);
  const cipher = createCipheriv(ALGORITHM, KEY, iv);
  const encrypted = Buffer.concat([cipher.update(text), cipher.final()]);
  return {
    iv: iv.toString('hex'),
    encryptedText: encrypted.toString('hex')
  };
}

export function decrypt(encryptedText: string, iv: string) {
  const decipher = createDecipheriv(ALGORITHM, KEY, Buffer.from(iv, 'hex'));
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(encryptedText, 'hex')),
    decipher.final()
  ]);
  return decrypted.toString();
}

export function anonymizeContent(content: string): string {
  // Basic anonymization - replace common PII patterns
  return content
    .replace(/[A-Z][a-z]+ [A-Z][a-z]+/g, '[NAME]')
    .replace(/\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g, '[PHONE]')
    .replace(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g, '[EMAIL]');
}

export function generateAnonymousId(): string {
  return randomBytes(16).toString('hex');
}
