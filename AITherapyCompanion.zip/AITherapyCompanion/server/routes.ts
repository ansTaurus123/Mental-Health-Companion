import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { generateTherapyResponse } from "./ai-service";
import { insertSessionSchema, insertMoodCheckSchema, insertScreeningSchema } from "@shared/schema";
import { z } from "zod";

const privacySettingsSchema = z.object({
  anonymousMode: z.boolean(),
  maskPersonalInfo: z.boolean(),
  dataRetentionDays: z.number().min(7).max(90)
});

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Add privacy settings endpoint
  app.patch("/api/user/privacy", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const settings = privacySettingsSchema.parse(req.body);
      const user = await storage.getUser(req.user.id);

      if (!user) return res.sendStatus(404);

      // Update user privacy settings
      const updatedUser = await storage.updateUser(user.id, {
        ...user,
        ...settings
      });

      res.json(updatedUser);
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : 'Invalid privacy settings'
      });
    }
  });

  app.post("/api/screening", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const screening = await storage.createScreening({
      userId: req.user.id,
      answers: req.body.answers,
      diagnoses: req.body.diagnoses,
      created: new Date()
    });

    await storage.updateUserScreeningStatus(req.user.id, true);
    res.json(screening);
  });

  app.post("/api/sessions", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // Generate AI response
      const aiResponse = await generateTherapyResponse(req.body.content);

      if (aiResponse.error) {
        console.error('AI Response Error:', aiResponse.error);
        return res.status(500).json({ 
          message: aiResponse.content,
          error: aiResponse.error 
        });
      }

      // Store the session
      const session = await storage.createSession({
        userId: req.user.id,
        content: req.body.content,
        aiResponse: aiResponse.content,
        created: new Date()
      });

      res.json(session);
    } catch (error) {
      console.error('Session creation error:', error);
      res.status(500).json({ 
        message: 'Failed to process therapy session. Please try again later.',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get("/api/sessions", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const sessions = await storage.getUserSessions(req.user.id);
    res.json(sessions);
  });

  app.post("/api/mood", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const moodCheck = await storage.createMoodCheck({
      userId: req.user.id,
      mood: req.body.mood,
      notes: req.body.notes,
      created: new Date()
    });

    res.json(moodCheck);
  });

  app.get("/api/mood", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const moodChecks = await storage.getUserMoodChecks(req.user.id);
    res.json(moodChecks);
  });

  const httpServer = createServer(app);
  return httpServer;
}