import { IStorage } from "./storage";
import createMemoryStore from "memorystore";
import session from "express-session";
import type { Session, MoodCheck, ScreeningResult, User } from "@shared/schema";
import { encrypt, decrypt, anonymizeContent, generateAnonymousId } from "./encryption-service";

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private sessions: Map<number, Session>;
  private moodChecks: Map<number, MoodCheck>;
  private screeningResults: Map<number, ScreeningResult>;
  sessionStore: session.Store;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.sessions = new Map();
    this.moodChecks = new Map();
    this.screeningResults = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(user: Omit<User, "id">): Promise<User> {
    const id = this.currentId++;
    const newUser = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  async updateUserScreeningStatus(userId: number, completed: boolean): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      user.screeningCompleted = completed;
      this.users.set(userId, user);
    }
  }

  async createSession(sessionData: Omit<Session, "id">): Promise<Session> {
    const id = this.currentId++;
    const user = await this.getUser(sessionData.userId);

    // Process content based on user privacy settings
    let content = sessionData.content;
    let aiResponse = sessionData.aiResponse;

    if (user?.maskPersonalInfo) {
      content = anonymizeContent(content);
      aiResponse = anonymizeContent(aiResponse);
    }

    // Encrypt the content
    const encryptedContent = encrypt(content);
    const encryptedResponse = encrypt(aiResponse);

    const session: Session = {
      ...sessionData,
      id,
      content: encryptedContent.encryptedText,
      aiResponse: encryptedResponse.encryptedText,
      encryptionIV: encryptedContent.iv,
      isAnonymized: user?.anonymousMode || false,
      anonymousId: user?.anonymousMode ? generateAnonymousId() : undefined,
      scheduledDeletion: user?.dataRetentionDays 
        ? new Date(Date.now() + user.dataRetentionDays * 24 * 60 * 60 * 1000)
        : undefined
    };

    this.sessions.set(id, session);
    return session;
  }

  async getUserSessions(userId: number): Promise<Session[]> {
    const user = await this.getUser(userId);
    if (!user) return [];

    const sessions = Array.from(this.sessions.values())
      .filter((session) => session.userId === userId)
      .map(session => ({
        ...session,
        content: decrypt(session.content, session.encryptionIV!),
        aiResponse: decrypt(session.aiResponse, session.encryptionIV!)
      }));

    // Clean up expired sessions
    const now = new Date();
    sessions.forEach(session => {
      if (session.scheduledDeletion && session.scheduledDeletion < now) {
        this.sessions.delete(session.id);
      }
    });

    return sessions.filter(session => 
      !session.scheduledDeletion || session.scheduledDeletion > now
    );
  }

  async createMoodCheck(moodCheck: Omit<MoodCheck, "id">): Promise<MoodCheck> {
    const id = this.currentId++;
    const newMoodCheck = { ...moodCheck, id };
    this.moodChecks.set(id, newMoodCheck);
    return newMoodCheck;
  }

  async getUserMoodChecks(userId: number): Promise<MoodCheck[]> {
    return Array.from(this.moodChecks.values()).filter(
      (moodCheck) => moodCheck.userId === userId,
    );
  }

  async createScreening(screening: Omit<ScreeningResult, "id">): Promise<ScreeningResult> {
    const id = this.currentId++;
    const newScreening = { ...screening, id };
    this.screeningResults.set(id, newScreening);
    return newScreening;
  }

  async getUserScreening(userId: number): Promise<ScreeningResult | undefined> {
    return Array.from(this.screeningResults.values()).find(
      (screening) => screening.userId === userId,
    );
  }
}

export const storage = new MemStorage();