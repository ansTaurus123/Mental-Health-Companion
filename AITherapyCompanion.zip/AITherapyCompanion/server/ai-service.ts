import { Mistral } from "@mistralai/mistralai";
import { z } from "zod";

// System prompt for the AI therapist
const THERAPY_SYSTEM_PROMPT = `You are an empathetic and professional AI therapist. Your responses should:
- Be supportive and non-judgmental
- Use evidence-based therapeutic techniques
- Focus on the patient's well-being and safety
- Maintain appropriate professional boundaries
- Recognize signs that require professional intervention
- Provide practical coping strategies when appropriate`;

// Schema for validating AI responses
const aiResponseSchema = z.object({
  content: z.string(),
  error: z.string().optional(),
});

export type AIResponse = z.infer<typeof aiResponseSchema>;

// Fallback responses in case of errors
const fallbackResponses = [
  "I understand you're going through a difficult time. Can you tell me more about how you're feeling?",
  "That sounds challenging. How long have you been experiencing these feelings?",
  "I hear you, and it's completely normal to feel this way. Let's explore some coping strategies together.",
  "Your feelings are valid. What kind of support do you feel would be most helpful right now?",
  "Thank you for sharing that with me. How have you been managing these feelings so far?",
];

// Function to get a random fallback response
function getFallbackResponse(): string {
  return fallbackResponses[
    Math.floor(Math.random() * fallbackResponses.length)
  ];
}

// Function to generate a therapy response using the Mistral API
export async function generateTherapyResponse(
  userMessage: string,
  maxRetries = 3,
): Promise<AIResponse> {
  // Check if the API key is available
  if (!process.env.MISTRAL_API_KEY) {
    console.error("MISTRAL_API_KEY is missing.");
    return {
      content: getFallbackResponse(),
      error: "Missing API key",
    };
  }

  // Initialize the Mistral client
  const client = new Mistral({ apiKey: process.env.MISTRAL_API_KEY });

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      console.log(`Attempt ${attempt + 1} of ${maxRetries}`);

      // Use the correct Mistral SDK method
      const result = await client.chat.stream({
        model: "mistral-small-latest",
        messages: [
          { role: "system", content: THERAPY_SYSTEM_PROMPT },
          { role: "user", content: userMessage },
        ],
      });

      let responseContent = "";

      for await (const chunk of result) {
        responseContent += chunk.data.choices[0]?.delta?.content || "";
      }

      if (!responseContent) {
        console.error("Unexpected empty response from API");
        return {
          content: getFallbackResponse(),
          error: "Unexpected empty response from API",
        };
      }

      return {
        content: responseContent,
      };
    } catch (error) {
      console.error("AI Service Error:", error);

      if (attempt < maxRetries - 1) {
        console.log(`Retrying... (${maxRetries - attempt - 1} retries left)`);
        continue;
      }

      return {
        content: getFallbackResponse(),
        error:
          error instanceof Error ? error.message : "Unknown error occurred",
      };
    }
  }

  return {
    content: getFallbackResponse(),
    error: "Maximum retries exceeded",
  };
}
