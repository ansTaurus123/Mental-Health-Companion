import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Clock, UserX } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";

interface PrivacySettingsProps {
  initialSettings: {
    anonymousMode: boolean;
    maskPersonalInfo: boolean;
    dataRetentionDays: number;
  };
  onUpdate: () => void;
}

export function PrivacySettings({ initialSettings, onUpdate }: PrivacySettingsProps) {
  const { toast } = useToast();
  const [settings, setSettings] = useState(initialSettings);

  const updateSettings = async (newSettings: Partial<typeof settings>) => {
    try {
      await apiRequest("PATCH", "/api/user/privacy", {
        ...settings,
        ...newSettings
      });
      
      setSettings(prev => ({ ...prev, ...newSettings }));
      onUpdate();
      
      toast({
        title: "Privacy settings updated",
        description: "Your changes have been saved successfully."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update privacy settings",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Privacy Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label className="text-base">Anonymous Mode</Label>
            <p className="text-sm text-muted-foreground">
              Hide your identity in therapy sessions
            </p>
          </div>
          <Switch
            checked={settings.anonymousMode}
            onCheckedChange={(checked) => updateSettings({ anonymousMode: checked })}
          />
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label className="text-base">Mask Personal Information</Label>
            <p className="text-sm text-muted-foreground">
              Automatically redact personal details from sessions
            </p>
          </div>
          <Switch
            checked={settings.maskPersonalInfo}
            onCheckedChange={(checked) => updateSettings({ maskPersonalInfo: checked })}
          />
        </div>

        <div className="space-y-4">
          <div className="space-y-0.5">
            <Label className="text-base">Data Retention Period</Label>
            <p className="text-sm text-muted-foreground">
              Choose how long to keep your session data
            </p>
          </div>
          <div className="space-y-4">
            <Slider
              value={[settings.dataRetentionDays]}
              onValueChange={([value]) => updateSettings({ dataRetentionDays: value })}
              max={90}
              min={7}
              step={1}
              className="w-full"
            />
            <div className="text-sm text-muted-foreground text-center">
              {settings.dataRetentionDays} days
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
