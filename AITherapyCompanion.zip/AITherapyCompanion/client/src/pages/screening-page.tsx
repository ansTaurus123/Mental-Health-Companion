import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { screeningQuestions } from "@shared/screening";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";

interface ScreeningForm {
  [key: string]: string;
}

export default function ScreeningPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [currentQuestion, setCurrentQuestion] = useState(0);

  const form = useForm<ScreeningForm>({
    defaultValues: screeningQuestions.reduce((acc, q) => ({ ...acc, [q.id]: "" }), {}),
  });

  const currentQ = screeningQuestions[currentQuestion];

  const onSubmit = async (data: ScreeningForm) => {
    try {
      // Calculate potential diagnoses based on answers
      const diagnoses = calculateDiagnoses(data);
      
      await apiRequest("POST", "/api/screening", {
        answers: data,
        diagnoses,
      });

      toast({
        title: "Screening completed",
        description: "Thank you for completing the assessment",
      });

      setLocation("/");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit screening results",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Mental Health Screening</CardTitle>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mt-4">
              <div
                className="bg-primary h-2.5 rounded-full transition-all"
                style={{
                  width: `${((currentQuestion + 1) / screeningQuestions.length) * 100}%`,
                }}
              />
            </div>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form className="space-y-6">
                <FormField
                  control={form.control}
                  name={currentQ.id}
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel className="text-lg font-medium">
                        {currentQ.text}
                      </FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="space-y-2"
                        >
                          {currentQ.options.map((option, i) => (
                            <FormItem
                              key={i}
                              className="flex items-center space-x-3 space-y-0"
                            >
                              <FormControl>
                                <RadioGroupItem value={option} />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                {option}
                              </FormLabel>
                            </FormItem>
                          ))}
                        </RadioGroup>
                      </FormControl>
                    </FormItem>
                  )}
                />

                <div className="flex justify-between pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                    disabled={currentQuestion === 0}
                  >
                    Previous
                  </Button>
                  {currentQuestion < screeningQuestions.length - 1 ? (
                    <Button
                      type="button"
                      onClick={() => {
                        if (form.getValues(currentQ.id)) {
                          setCurrentQuestion(currentQuestion + 1);
                        } else {
                          toast({
                            title: "Please select an option",
                            variant: "destructive",
                          });
                        }
                      }}
                    >
                      Next
                    </Button>
                  ) : (
                    <Button
                      onClick={form.handleSubmit(onSubmit)}
                    >
                      Complete Screening
                    </Button>
                  )}
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function calculateDiagnoses(answers: ScreeningForm): string[] {
  const diagnoses: string[] = [];
  const scores = {
    anxiety: 0,
    depression: 0,
    ptsd: 0,
    adhd: 0,
  };

  // Calculate scores based on answers
  Object.entries(answers).forEach(([id, answer]) => {
    const [category] = id.split("_");
    const score = getAnswerScore(answer);
    scores[category as keyof typeof scores] += score;
  });

  // Determine potential diagnoses based on scores
  if (scores.anxiety >= 4) diagnoses.push("Anxiety");
  if (scores.depression >= 4) diagnoses.push("Depression");
  if (scores.ptsd >= 6) diagnoses.push("PTSD");
  if (scores.adhd >= 6) diagnoses.push("ADHD");

  return diagnoses;
}

function getAnswerScore(answer: string): number {
  const scoreMap: Record<string, number> = {
    "Not at all": 0,
    "Several days": 1,
    "More than half the days": 2,
    "Nearly every day": 3,
    "Never": 0,
    "Rarely": 1,
    "Sometimes": 2,
    "Often": 3,
    "Very Often": 4,
    "A little bit": 1,
    "Moderately": 2,
    "Quite a bit": 3,
    "Extremely": 4,
  };
  return scoreMap[answer] || 0;
}
