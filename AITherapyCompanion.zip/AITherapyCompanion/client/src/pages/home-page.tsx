import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Brain, Clock, LineChart, MessageSquare, Dumbbell } from "lucide-react";

export default function HomePage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-blue-800">
            Welcome, {user?.fullName}
          </h1>
          <p className="mt-2 text-lg text-blue-700">
            Your mental wellness journey continues here
          </p>
        </header>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {!user?.screeningCompleted && (
            <Card className="col-span-full bg-primary/5 border-primary shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <CardTitle className="text-primary">Complete Your Initial Assessment</CardTitle>
                <CardDescription>
                  Take a brief screening to help us understand your needs better
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/screening">
                  <Button className="w-full">Start Assessment</Button>
                </Link>
              </CardContent>
            </Card>
          )}

          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-blue-500" />
                Start Therapy Session
              </CardTitle>
              <CardDescription>
                Connect with our AI therapist for support and guidance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/session">
                <Button variant="secondary" className="w-full">
                  Begin Session
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Dumbbell className="h-5 w-5 text-green-500" />
                Mental Wellness Exercises
              </CardTitle>
              <CardDescription>
                Practice exercises tailored to your needs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/exercises">
                <Button variant="secondary" className="w-full">
                  View Exercises
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LineChart className="h-5 w-5 text-purple-500" />
                Track Progress
              </CardTitle>
              <CardDescription>
                View your journey and track your improvement
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/progress">
                <Button variant="secondary" className="w-full">
                  View Progress
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 grid md:grid-cols-2 gap-8">
          <img
            src="https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&q=80"
            alt="Peaceful meditation scene"
            className="rounded-lg object-cover h-64 w-full shadow-xl"
          />
          <div className="flex flex-col justify-center">
            <h2 className="text-2xl font-bold text-blue-900 mb-4">
              Your Safe Space for Mental Wellness
            </h2>
            <p className="text-blue-700">
              MindfulCare provides you with professional AI-powered therapy sessions,
              progress tracking, personalized exercises, and comprehensive support
              for your mental health journey.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}