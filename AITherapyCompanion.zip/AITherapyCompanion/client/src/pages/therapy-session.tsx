import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Send, AlertTriangle } from "lucide-react";

interface Message {
  content: string;
  isUser: boolean;
  timestamp: Date;
  error?: boolean;
}

export default function TherapySession() {
  const [messages, setMessages] = useState<Message[]>([{
    content: "Hello! I'm here to listen and help. How are you feeling today?",
    isUser: false,
    timestamp: new Date(),
  }]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = {
      content: input.trim(),
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await apiRequest("POST", "/api/sessions", {
        content: userMessage.content,
      });

      const data = await response.json();

      setMessages(prev => [...prev, {
        content: data.aiResponse,
        isUser: false,
        timestamp: new Date(),
        error: data.error ? true : false
      }]);

      if (data.error) {
        console.warn('AI Response Warning:', data.error);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get response from therapist. Please try again.",
        variant: "destructive",
      });

      setMessages(prev => [...prev, {
        content: "I apologize, but I'm having trouble responding right now. Please try again in a moment.",
        isUser: false,
        timestamp: new Date(),
        error: true
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6">
      <div className="max-w-4xl mx-auto">
        <Card className="h-[80vh] flex flex-col">
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message, i) => (
                <div
                  key={i}
                  className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-4 ${
                      message.isUser
                        ? "bg-primary text-primary-foreground"
                        : message.error
                        ? "bg-destructive/10 border border-destructive/20"
                        : "bg-muted"
                    }`}
                  >
                    {message.error && !message.isUser && (
                      <AlertTriangle className="h-4 w-4 text-destructive mb-2" />
                    )}
                    <p className="text-sm">{message.content}</p>
                    <span className="text-xs opacity-70 mt-2 block">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg p-4">
                    <Loader2 className="h-5 w-5 animate-spin" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
          <CardContent className="border-t p-4">
            <form onSubmit={handleSubmit} className="flex gap-4">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message here..."
                className="min-h-[60px]"
                disabled={isLoading}
              />
              <Button type="submit" disabled={isLoading || !input.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}