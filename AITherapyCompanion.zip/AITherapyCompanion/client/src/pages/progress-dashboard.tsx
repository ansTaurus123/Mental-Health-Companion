import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { MoodCheck } from "@shared/schema";
import { Loader2 } from "lucide-react";

interface MoodCheckForm {
  mood: number;
  notes: string;
}

export default function ProgressDashboard() {
  const { toast } = useToast();
  const form = useForm<MoodCheckForm>({
    defaultValues: {
      mood: 5,
      notes: "",
    },
  });

  const { data: moodChecks, isLoading } = useQuery<MoodCheck[]>({
    queryKey: ["/api/mood"],
  });

  const onSubmit = async (data: MoodCheckForm) => {
    try {
      await apiRequest("POST", "/api/mood", data);
      form.reset();
      toast({
        title: "Mood check-in recorded",
        description: "Thank you for sharing how you're feeling",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to record mood check-in",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const chartData = moodChecks?.map(check => ({
    date: new Date(check.created).toLocaleDateString(),
    mood: check.mood,
  })) || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold text-blue-900">Your Progress Dashboard</h1>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Mood Tracker</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <XAxis dataKey="date" />
                    <YAxis domain={[0, 10]} />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="mood"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Daily Check-in</CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="mood"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>How are you feeling today? (0-10)</FormLabel>
                        <FormControl>
                          <input
                            type="range"
                            min="0"
                            max="10"
                            step="1"
                            {...field}
                            className="w-full"
                          />
                        </FormControl>
                        <div className="text-center font-medium">
                          {field.value}
                        </div>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Any thoughts you'd like to share?</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            placeholder="Write your thoughts here..."
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full">
                    Save Check-in
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {moodChecks?.slice(-3).reverse().map((check, i) => (
            <Card key={i}>
              <CardHeader>
                <CardTitle className="text-sm text-muted-foreground">
                  {new Date(check.created).toLocaleDateString()}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="font-medium mb-2">Mood: {check.mood}/10</div>
                {check.notes && <p className="text-sm">{check.notes}</p>}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
