import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { exercises } from "@shared/exercises";
import { Brain, Clock, CheckCircle, List } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";

export default function ExercisesPage() {
  const { user } = useAuth();
  const [activeExercise, setActiveExercise] = useState<string | null>(null);

  const userConditions = user?.diagnoses || [];

  const recommendedExercises = exercises.filter(exercise =>
    exercise.targetConditions.some(condition => userConditions.includes(condition))
  );

  const otherExercises = exercises.filter(exercise =>
    !exercise.targetConditions.some(condition => userConditions.includes(condition))
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <header>
          <h1 className="text-3xl font-bold text-blue-900">Mental Wellness Exercises</h1>
          <p className="mt-2 text-lg text-blue-700">
            Practice these exercises to support your mental health journey
          </p>
        </header>

        {recommendedExercises.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold text-blue-800 mb-4">
              Recommended for You
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {recommendedExercises.map(exercise => (
                <ExerciseCard
                  key={exercise.id}
                  exercise={exercise}
                  isActive={activeExercise === exercise.id}
                  onToggle={() => setActiveExercise(activeExercise === exercise.id ? null : exercise.id)}
                />
              ))}
            </div>
          </section>
        )}

        <section>
          <h2 className="text-xl font-semibold text-blue-800 mb-4">
            All Exercises
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {otherExercises.map(exercise => (
              <ExerciseCard
                key={exercise.id}
                exercise={exercise}
                isActive={activeExercise === exercise.id}
                onToggle={() => setActiveExercise(activeExercise === exercise.id ? null : exercise.id)}
              />
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}

function ExerciseCard({ exercise, isActive, onToggle }: {
  exercise: typeof exercises[0];
  isActive: boolean;
  onToggle: () => void;
}) {
  return (
    <Card className="transition-all hover:shadow-lg">
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl font-semibold">{exercise.title}</CardTitle>
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span className="text-sm">{exercise.duration}</span>
          </div>
        </div>
        <CardDescription>{exercise.description}</CardDescription>
        <div className="flex gap-2 flex-wrap mt-2">
          {exercise.targetConditions.map(condition => (
            <Badge key={condition} variant="secondary">
              {condition}
            </Badge>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        {!isActive ? (
          <Button 
            onClick={onToggle}
            variant="outline" 
            className="w-full"
          >
            <Brain className="mr-2 h-4 w-4" />
            Start Exercise
          </Button>
        ) : (
          <div className="space-y-4">
            <div>
              <h4 className="font-medium flex items-center gap-2 mb-2">
                <List className="h-4 w-4" />
                Instructions
              </h4>
              <ScrollArea className="h-[200px] rounded-md border p-4">
                <ol className="list-decimal list-inside space-y-2">
                  {exercise.instructions.map((step, index) => (
                    <li key={index} className="text-sm">{step}</li>
                  ))}
                </ol>
              </ScrollArea>
            </div>
            <div>
              <h4 className="font-medium flex items-center gap-2 mb-2">
                <CheckCircle className="h-4 w-4" />
                Benefits
              </h4>
              <ul className="list-disc list-inside space-y-1">
                {exercise.benefits.map((benefit, index) => (
                  <li key={index} className="text-sm text-muted-foreground">{benefit}</li>
                ))}
              </ul>
            </div>
            <Button 
              onClick={onToggle}
              variant="outline" 
              className="w-full"
            >
              Close
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
