export const screeningQuestions = [
  {
    id: "anxiety_1",
    text: "How often do you feel nervous, anxious, or on edge?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: "anxiety_2",
    text: "How often do you have trouble relaxing?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: "depression_1", 
    text: "How often do you feel down, depressed, or hopeless?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: "depression_2",
    text: "How often do you have little interest or pleasure in doing things?",
    options: ["Not at all", "Several days", "More than half the days", "Nearly every day"]
  },
  {
    id: "ptsd_1",
    text: "Do you have repeated, disturbing memories of a stressful experience?",
    options: ["Not at all", "A little bit", "Moderately", "Quite a bit", "Extremely"]
  },
  {
    id: "ptsd_2", 
    text: "Do you feel very upset when something reminds you of a stressful experience?",
    options: ["Not at all", "A little bit", "Moderately", "Quite a bit", "Extremely"]
  },
  {
    id: "adhd_1",
    text: "How often do you have difficulty concentrating on tasks?",
    options: ["Never", "Rarely", "Sometimes", "Often", "Very Often"]
  },
  {
    id: "adhd_2",
    text: "How often do you feel restless or have trouble sitting still?",
    options: ["Never", "Rarely", "Sometimes", "Often", "Very Often"]
  }
];

export const emergencyResources = {
  suicide_prevention: {
    name: "National Suicide Prevention Lifeline",
    phone: "988",
    available: "24/7"
  },
  crisis_text: {
    name: "Crisis Text Line",
    text: "HOME to 741741",
    available: "24/7"
  },
  samhsa: {
    name: "SAMHSA Treatment Referral Helpline",
    phone: "1-800-662-4357",
    available: "24/7"
  }
};
