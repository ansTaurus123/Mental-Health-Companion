import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  screeningCompleted: boolean("screening_completed").default(false),
  diagnoses: text("diagnoses").array(),
  created: timestamp("created").defaultNow(),
  // Added privacy settings
  dataRetentionDays: integer("data_retention_days").default(30),
  anonymousMode: boolean("anonymous_mode").default(false),
  maskPersonalInfo: boolean("mask_personal_info").default(true)
});

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  // Change content and aiResponse to store encrypted data
  content: text("content").notNull(),
  aiResponse: text("ai_response").notNull(),
  created: timestamp("created").defaultNow(),
  // Add encryption metadata
  encryptionIV: text("encryption_iv"),
  // Add anonymization flags
  isAnonymized: boolean("is_anonymized").default(false),
  anonymousId: text("anonymous_id"),
  scheduledDeletion: timestamp("scheduled_deletion")
});

export const moodChecks = pgTable("mood_checks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mood: integer("mood").notNull(),
  notes: text("notes"),
  created: timestamp("created").defaultNow()
});

export const screeningResults = pgTable("screening_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  answers: json("answers").notNull(),
  diagnoses: text("diagnoses").array(),
  created: timestamp("created").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  email: true,
  anonymousMode: true,
  maskPersonalInfo: true
});

export const insertSessionSchema = createInsertSchema(sessions);
export const insertMoodCheckSchema = createInsertSchema(moodChecks);
export const insertScreeningSchema = createInsertSchema(screeningResults);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type MoodCheck = typeof moodChecks.$inferSelect;
export type ScreeningResult = typeof screeningResults.$inferSelect;