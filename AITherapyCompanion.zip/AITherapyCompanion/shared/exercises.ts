import { z } from "zod";

export interface Exercise {
  id: string;
  title: string;
  description: string;
  duration: string;
  targetConditions: string[];
  instructions: string[];
  benefits: string[];
}

export const exercises: Exercise[] = [
  {
    id: "breathing-technique",
    title: "4-7-8 Breathing Exercise",
    description: "A calming breathing technique that helps reduce anxiety and stress",
    duration: "5 minutes",
    targetConditions: ["Anxiety", "Stress", "PTSD"],
    instructions: [
      "Find a comfortable sitting position",
      "Exhale completely through your mouth",
      "Close your mouth and inhale through your nose for 4 counts",
      "Hold your breath for 7 counts",
      "Exhale completely through your mouth for 8 counts",
      "Repeat this cycle 4 times"
    ],
    benefits: [
      "Reduces anxiety",
      "Helps with sleep",
      "Decreases stress response",
      "Improves focus"
    ]
  },
  {
    id: "gratitude-journal",
    title: "Daily Gratitude Journal",
    description: "Practice mindfulness and positivity by recording things you're grateful for",
    duration: "10 minutes",
    targetConditions: ["Depression", "Anxiety"],
    instructions: [
      "Find a quiet space",
      "Write down three things you're grateful for today",
      "For each item, write why it makes you feel grateful",
      "Reflect on how these positive elements affect your life"
    ],
    benefits: [
      "Improves mood",
      "Increases optimism",
      "Enhances self-awareness",
      "Builds resilience"
    ]
  },
  {
    id: "progressive-relaxation",
    title: "Progressive Muscle Relaxation",
    description: "Systematically tense and relax muscle groups to reduce physical tension",
    duration: "15 minutes",
    targetConditions: ["Anxiety", "PTSD", "Stress"],
    instructions: [
      "Lie down in a comfortable position",
      "Starting with your toes, tense the muscles for 5 seconds",
      "Release and feel the tension flow away for 10 seconds",
      "Move up through each muscle group",
      "End with facial muscles"
    ],
    benefits: [
      "Reduces physical tension",
      "Improves body awareness",
      "Helps with anxiety symptoms",
      "Better sleep quality"
    ]
  },
  {
    id: "focus-exercise",
    title: "5-4-3-2-1 Grounding Exercise",
    description: "A mindfulness technique to help with concentration and anxiety",
    duration: "5 minutes",
    targetConditions: ["ADHD", "Anxiety", "PTSD"],
    instructions: [
      "Name 5 things you can see",
      "Name 4 things you can touch/feel",
      "Name 3 things you can hear",
      "Name 2 things you can smell",
      "Name 1 thing you can taste"
    ],
    benefits: [
      "Improves focus",
      "Reduces anxiety",
      "Helps with panic attacks",
      "Increases present-moment awareness"
    ]
  }
];

export const exerciseSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  duration: z.string(),
  targetConditions: z.array(z.string()),
  instructions: z.array(z.string()),
  benefits: z.array(z.string())
});

export type ExerciseProgress = {
  exerciseId: string;
  completed: boolean;
  notes: string;
  timestamp: Date;
};
